export default {
  //Site display name
  SITE_TITLE: "VoidPlus",

  //Put your discord link here or null to disable
  SITE_DISCORD: "https://discord.gg/kry6dtppCU",
  
  //True or false to show or hide site credit in footer (You should leave enabled 😉)
  SITE_CREDITS: false,

  //Do not change or site will break!
  RIPPER_API: "https://api.ripper.fun"
}